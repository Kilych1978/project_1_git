@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "point_args=%*"
if "%~1"=="" set "point_args=7:28.755 52:05.916 52:15.301"
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" collect_audio_points.py %point_args%
    goto finished
)
where py >nul 2>nul
if not errorlevel 1 (
    py -3 collect_audio_points.py %point_args%
    goto finished
)
where python >nul 2>nul
if not errorlevel 1 (
    python collect_audio_points.py %point_args%
    goto finished
)
echo Python не найден. Нужен Python 3.11 или новее.
:finished
pause
